
module.exports = require("./dist/houndify-node");

module.exports["HoundifyExpress"] = require("./dist/houndify-express");